PROFILE APP — RIZKY GINTING

Perubahan yang dilakukan:
- Nama aplikasi dan profil default menjadi Rizky Ginting.
- Username default: rizky.ginting.
- Package/namespace/applicationId menjadi com.rizkyginting.profileapp.
- Foto selfie digunakan sebagai foto profil.
- Foto kebun digunakan sebagai foto sampul.
- Tiga foto lainnya otomatis dimasukkan ke album saat aplikasi pertama kali dibuka.
- Warna aksen diperbarui menjadi hijau agar sesuai dengan foto kebun.
- Fitur edit profil, ganti foto, tambah/hapus foto, follow, pesan, dan berbagi profil tetap dipertahankan.

CARA MEMBUKA:
1. Ekstrak ZIP ini.
2. Buka Android Studio.
3. Pilih Open, lalu pilih folder RizkyGintingProfile hasil ekstraksi.
4. Tunggu Gradle Sync selesai.
5. Jalankan aplikasi menggunakan emulator atau HP Android.

CATATAN:
ZIP ini berisi kode sumber proyek. APK belum dibangun ulang setelah perubahan; jalankan Build > Build APK(s) di Android Studio untuk membuat APK terbaru.
Alamat email default rizky.ginting@example.com hanyalah contoh dan bisa diganti melalui Edit Profil.
