package com.rizkyginting.profileapp;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ProfileActivity extends AppCompatActivity {

    private static final String STATE_FOLLOWING = "following";
    private static final int POST_COLUMNS = 4;
    private static final int AVATAR_PX = 512;
    private static final int COVER_PX = 1280;
    private static final int ALBUM_PX = 1080;

    private static final String[] FOLLOWERS = {
            "Rizky Ginting", "Ahmad Rizky", "Siti Aulia", "Dimas Pratama", "Putri Maharani"
    };

    private TextView tvName, tvBio, tvPostsCount, tvEmptyPosts;
    private ImageView ivCover, ivAvatar;
    private GridLayout glPosts;
    private Button btnFollow;
    private boolean following;

    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private final ActivityResultLauncher<String> pickAvatar = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> saveSingle(uri, ImageStore.avatarFile(this), AVATAR_PX));
    private final ActivityResultLauncher<String> pickCover = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> saveSingle(uri, ImageStore.coverFile(this), COVER_PX));
    private final ActivityResultLauncher<String> pickAlbum = registerForActivityResult(
            new ActivityResultContracts.GetMultipleContents(), this::saveAlbum);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        tvName = findViewById(R.id.tvName);
        tvBio = findViewById(R.id.tvBio);
        tvPostsCount = findViewById(R.id.tvPostsCount);
        tvEmptyPosts = findViewById(R.id.tvEmptyPosts);
        ivCover = findViewById(R.id.ivCover);
        ivAvatar = findViewById(R.id.ivAvatar);
        glPosts = findViewById(R.id.glPosts);
        btnFollow = findViewById(R.id.btnFollow);

        if (savedInstanceState != null) {
            following = savedInstanceState.getBoolean(STATE_FOLLOWING, false);
        }
        updateFollowButton();
        btnFollow.setOnClickListener(v -> {
            following = !following;
            updateFollowButton();
        });

        ivAvatar.setOnClickListener(v -> pickAvatar.launch("image/*"));
        findViewById(R.id.btnChangeCover).setOnClickListener(v -> pickCover.launch("image/*"));

        findViewById(R.id.tvEditProfile).setOnClickListener(v ->
                startActivity(new Intent(this, EditProfileActivity.class)));

        findViewById(R.id.btnShare).setOnClickListener(v -> {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_TEXT, tvName.getText() + " (@"
                    + ProfileStore.get(this, ProfileStore.KEY_USERNAME) + ")");
            startActivity(Intent.createChooser(send, getString(R.string.share)));
        });

        findViewById(R.id.btnMessage).setOnClickListener(v -> {
            Intent mail = new Intent(Intent.ACTION_SENDTO);
            mail.setData(Uri.parse("mailto:" + ProfileStore.get(this, ProfileStore.KEY_CONTACT)));
            if (mail.resolveActivity(getPackageManager()) != null) {
                startActivity(mail);
            } else {
                Toast.makeText(this, R.string.message, Toast.LENGTH_SHORT).show();
            }
        });

        findViewById(R.id.tvViewAll).setOnClickListener(v ->
                Toast.makeText(this, R.string.view_all, Toast.LENGTH_SHORT).show());

        buildFollowers();
    }

    @Override
    protected void onResume() {
        super.onResume();
        tvName.setText(ProfileStore.get(this, ProfileStore.KEY_NAME));
        tvBio.setText(ProfileStore.get(this, ProfileStore.KEY_BIO));
        io.execute(this::loadAndShow);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean(STATE_FOLLOWING, following);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        io.shutdown();
    }

    // ---------- simpan foto ----------

    private void saveSingle(Uri uri, File dest, int maxPx) {
        if (uri == null) return;
        io.execute(() -> {
            boolean ok = ImageStore.saveFromUri(getApplicationContext(), uri, dest, maxPx);
            if (!ok) toastOnUi(R.string.photo_error);
            loadAndShow();
        });
    }

    private void saveAlbum(List<Uri> uris) {
        if (uris == null || uris.isEmpty()) return;
        io.execute(() -> {
            long now = System.currentTimeMillis();
            int failed = 0;
            for (int i = 0; i < uris.size(); i++) {
                File dest = new File(ImageStore.albumDir(this),
                        String.format(Locale.US, "a_%013d_%03d.jpg", now, i));
                if (!ImageStore.saveFromUri(getApplicationContext(), uris.get(i), dest, ALBUM_PX)) {
                    failed++;
                }
            }
            if (failed > 0) toastOnUi(R.string.some_failed);
            loadAndShow();
        });
    }

    private void toastOnUi(int resId) {
        runOnUiThread(() -> Toast.makeText(this, resId, Toast.LENGTH_SHORT).show());
    }

    // ---------- tampilkan ----------

    /** Dijalankan di thread background; hasilnya dikirim ke UI thread. */
    private void loadAndShow() {
        ImageStore.seedDefaultPhotos(getApplicationContext());
        int width = getResources().getDisplayMetrics().widthPixels;
        Bitmap cover = ImageStore.load(ImageStore.coverFile(this), width);
        Bitmap avatar = ImageStore.load(ImageStore.avatarFile(this), dp(104));
        List<File> files = ImageStore.albumFiles(this);
        List<Bitmap> thumbs = new ArrayList<>();
        for (File f : files) thumbs.add(ImageStore.load(f, width / POST_COLUMNS));

        runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) return;
            if (cover != null) ivCover.setImageBitmap(cover); else ivCover.setImageDrawable(null);
            if (avatar != null) ivAvatar.setImageBitmap(avatar);
            else ivAvatar.setImageResource(R.drawable.ic_avatar);
            tvPostsCount.setText(String.valueOf(files.size()));
            tvEmptyPosts.setVisibility(files.isEmpty() ? View.VISIBLE : View.GONE);
            buildGrid(files, thumbs);
        });
    }

    private void buildGrid(List<File> files, List<Bitmap> thumbs) {
        glPosts.removeAllViews();
        int margin = dp(1);
        int size = getResources().getDisplayMetrics().widthPixels / POST_COLUMNS - margin * 2;

        ImageView add = new ImageView(this);
        add.setBackgroundColor(0xFFEFEDF4);
        add.setImageResource(R.drawable.ic_add);
        add.setScaleType(ImageView.ScaleType.CENTER);
        add.setContentDescription(getString(R.string.add_photos));
        add.setOnClickListener(v -> pickAlbum.launch("image/*"));
        glPosts.addView(add, tileParams(0, size, margin));

        for (int i = 0; i < files.size(); i++) {
            File file = files.get(i);
            ImageView tile = new ImageView(this);
            tile.setBackgroundColor(0xFFDAD7E2);
            tile.setScaleType(ImageView.ScaleType.CENTER_CROP);
            tile.setImageBitmap(thumbs.get(i));
            tile.setContentDescription("Post " + (i + 1));
            tile.setOnClickListener(v -> showFull(file));
            tile.setOnLongClickListener(v -> {
                confirmDelete(file);
                return true;
            });
            glPosts.addView(tile, tileParams(i + 1, size, margin));
        }
    }

    private GridLayout.LayoutParams tileParams(int index, int size, int margin) {
        GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                GridLayout.spec(index / POST_COLUMNS), GridLayout.spec(index % POST_COLUMNS));
        lp.width = size;
        lp.height = size;
        lp.setMargins(margin, margin, margin, margin);
        return lp;
    }

    private void showFull(File file) {
        Bitmap b = ImageStore.load(file, getResources().getDisplayMetrics().widthPixels);
        if (b == null) return;
        Dialog d = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        ImageView v = new ImageView(this);
        v.setBackgroundColor(Color.BLACK);
        v.setScaleType(ImageView.ScaleType.FIT_CENTER);
        v.setImageBitmap(b);
        v.setOnClickListener(x -> d.dismiss());
        d.setContentView(v);
        d.show();
    }

    private void confirmDelete(File file) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_photo)
                .setPositiveButton(R.string.delete, (dlg, w) -> {
                    file.delete();
                    io.execute(this::loadAndShow);
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void updateFollowButton() {
        btnFollow.setText(following ? R.string.following : R.string.follow);
    }

    private void buildFollowers() {
        LinearLayout row = findViewById(R.id.llFollowers);
        LayoutInflater inflater = LayoutInflater.from(this);
        for (String name : FOLLOWERS) {
            View item = inflater.inflate(R.layout.item_follower, row, false);
            ((TextView) item.findViewById(R.id.tvFollowerName)).setText(name);
            item.findViewById(R.id.ivFollower).setContentDescription(name);
            row.addView(item);
        }
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
